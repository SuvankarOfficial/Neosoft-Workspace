package com.travel.review.management;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReviewManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReviewManagementApplication.class, args);
	}

}
