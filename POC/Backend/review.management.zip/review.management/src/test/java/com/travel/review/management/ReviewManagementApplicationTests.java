package com.travel.review.management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReviewManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
