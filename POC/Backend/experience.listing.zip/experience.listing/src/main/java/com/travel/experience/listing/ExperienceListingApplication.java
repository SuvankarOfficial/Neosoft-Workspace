package com.travel.experience.listing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExperienceListingApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExperienceListingApplication.class, args);
	}

}
