package com.travel.experience.listing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExperienceListingApplicationTests {

	@Test
	void contextLoads() {
	}

}
