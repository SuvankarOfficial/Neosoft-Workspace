package com.itinerary.itinerary.management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ItineraryManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
