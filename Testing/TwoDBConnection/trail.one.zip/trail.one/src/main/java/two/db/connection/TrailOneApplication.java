package two.db.connection;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrailOneApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrailOneApplication.class, args);
	}

}
